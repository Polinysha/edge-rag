from langchain_text_splitters import RecursiveCharacterTextSplitter

CHUNK_SIZE = 400
CHUNK_OVERLAP = 80

splitter = RecursiveCharacterTextSplitter(
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP,
)


def chunk_pages(pages: list[dict]) -> list[dict]:

    chunks = []
    chunk_idx = 0

    for page in pages:
        page_chunks = splitter.split_text(page["text"])
        for chunk_text in page_chunks:
            if not chunk_text.strip():
                continue
            chunks.append({
                "text": chunk_text,
                "source": page["source"],
                "page_num": page["page_num"],
                "chunk_idx": chunk_idx,
            })
            chunk_idx += 1

    return chunks


if __name__ == "__main__":
    import sys
    sys.path.insert(0, "../pipeline")
    from src.pipeline.extraction import extract_pdf

    test_path = sys.argv[1] if len(sys.argv) > 1 else "data/test.pdf"
    pages = extract_pdf(test_path)
    chunks = chunk_pages(pages)

    print(f"Pages: {len(pages)}, chunks: {len(chunks)}")
    print()
    for c in chunks[:3]:
        print(f"--- chunk_idx={c['chunk_idx']}, page_num={c['page_num']}, source={c['source']} ---")
        print(f"text length: {len(c['text'])}")
        print(c["text"][:150])
        print()